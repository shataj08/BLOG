import logo from './logo.svg';
import './App.css';

import Login from './components/account/Login';
function App() {
  return (
    <div style={{marginTop: 60, marginBottom: 64}}>
         <Login />
    </div>
  );
}

export default App;
